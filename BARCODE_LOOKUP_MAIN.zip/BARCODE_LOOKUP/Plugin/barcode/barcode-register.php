<?php
	require_once ('../../../wp-config.php');
	if(current_user_can('administrator')){
		$barcode = sanitize_text_field($_POST["barcode"]);
		$table_name = $wpdb->prefix . "barcode";
		if(empty($barcode)){
			$url = 'https://'.$_SERVER['HTTP_REFERER'];
			header("Location: ".$url);
			exit;
		}
		else if(strstr($barcode, ',')){
			$barcode_list = explode(',', $barcode);
			for($i = 0; $i < count($barcode_list); $i++){
				$barcode_kontrol = $wpdb->get_col("SELECT barcode FROM $table_name WHERE barcode='$barcode_list[$i]' ");
				if(!$barcode_kontrol){
					$barcode_kayit = $wpdb->insert($table_name, array('barcode' => $barcode_list[$i]));
				}
			}
		}
		else {
			$barcode_kontrol = $wpdb->get_col("SELECT barcode FROM $table_name WHERE barcode='$barcode' ");
			if($barcode_kontrol){
				$ref = $_SERVER['HTTP_REFERER']."&status=2";
				header("Location: ".$ref);
		 		exit;
			}
			$barcode_kayit = $wpdb->insert($table_name, array('barcode' => $barcode));
		}

	 	if($barcode_kayit){
			$ref = $_SERVER['HTTP_REFERER']."&status=1";
			header("Location: ".$ref);
	 	}
	 	else {
	 		$ref = $_SERVER['HTTP_REFERER']."&status=3";
			header("Location: ".$ref);
	 	}
	 	exit;
	}
	else {
		$site = "https://".$_SERVER['SERVER_NAME'];
		header("Location: ".$site);
		exit;
	}
?>