<?php
	require_once ('../../../wp-config.php');
	if(current_user_can('administrator')){
		$barcode_id = intval($_GET["barcode_id"]);
		$url = $_SERVER['HTTP_REFERER'];

		if(empty($barcode_id)){
			header("Location: ".$url);
			exit;
		}

   		$table_name = $wpdb->prefix . "barcode";
   		$wpdb->delete( $table_name, array( 'id' => $barcode_id ) );
		
		header("Location: ".$url);
	 	exit;
	}
	else {
		$site = "https://".$_SERVER['SERVER_NAME'];
		header("Location: ".$site);
		exit;
	}
?>