<?php
/*
Plugin Name: Barcode Lookup
Description: Barkod Lookup Plugin from Medialesta
Version: 1.0
Author: Medialesta
Author URI: https://medialesta.com.tr/
License: GNU
*/	
defined( 'WPINC' ) || exit;
	global $wpdb;

	add_action('wp_enqueue_scripts', 'callback_for_setting_up_scripts');
	function callback_for_setting_up_scripts() {
	    wp_register_style( 'style', plugins_url("/barcode/assets/css/style.css") );
	    wp_enqueue_style( 'style' );
	}


	add_action('admin_enqueue_scripts', 'callback_for_admin_setting_up_scripts');
	function callback_for_admin_setting_up_scripts() {
	    wp_register_style( 'admin-style', plugins_url("/barcode/assets/css/admin.css") );
	    wp_enqueue_style( 'admin-style' );
	}


    function creating_plugin_table(){
		global $wpdb;
   		$table_name = $wpdb->prefix . "barcode";
	   	if(!$wpdb->get_var("show tables like '$table_name'")){
		    $sql = "CREATE TABLE ".$table_name." (
		      	id bigint(20) NOT NULL AUTO_INCREMENT,
		      	barcode text(500) NOT NULL,
		      	query_time int(100) NOT NULL,
		      	UNIQUE KEY id (id)
		    )";
	      	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	      	dbDelta($sql);
	   	}
	}

	register_activation_hook( __FILE__, 'creating_plugin_table' );

	function creating_post(){
	    // Create post object
	    $my_post = array(
	      'post_title'    => wp_strip_all_tags( 'Originality' ),
	      'post_content'  => '[barcode_reader]',
	      'post_status'   => 'publish',
	      'post_author'   => 1,
	      'post_type'     => 'page',
	    );

	    // Insert the post into the database
	    wp_insert_post( $my_post );
	}

	register_activation_hook( __FILE__, 'creating_post' );


	function barcode_manage(){
		global $wpdb;
   		wp_enqueue_style('admin-style');
   		$table_name = $wpdb->prefix . "barcode";
		$status = intval($_GET['status']);
		if(isset($status) && is_numeric($status)){
			switch($status){
				case 0:
					break;
				case 1:
					$status_cikti = '<span style="color: #4be159">Barcode created..</span>';
					break;
				case 2:
					$status_cikti = '<span style="color: red">This barcode already registered!</span>';
					break;
				case 3:
					$status_cikti = '<span style="color: red">Error, couldn\'t created barcode!!</span>';
					break;
				default:
					$status_cikti = '<span style="color: red">ERROR! Couldn\'t found the status code!!</span>';
					break;
			}
		}
		echo '
		<div class="admin-barcode row" style="margin: 0">
			<div class="col-md-6 col-12">
				<h1>Barcode List</h1>
				<div class="col-12">
					<div class="inside">
						<table  class="form-table">
							<tr>
								<td scope="row" valign="top">
									<b>Registered Barcode</b>
								</td>
								<td>
									<b>Query Time</b>
								</td>
								<td>
									<b>Delete</b>
								</td>
							</tr>';
								$allbarcode = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
								$barcode_count = $wpdb->num_rows;
								if($barcode_count){
									foreach ($allbarcode as $singlebarcode) { 
										echo '<tr><td>'.$singlebarcode->barcode . '</td><td>'.$singlebarcode->query_time.'</td><td><a style="text-decoration:none; color: red" href="'.plugins_url("/barcode/barcode-delete.php").'?barcode_id='.$singlebarcode->id.'">X</a></td></tr>';
									}
								}
								else {
									echo '<tr><td><span style="color: red">Couldn\' find any barcode..</span></td></tr>';
								}
							echo '
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-5 col-12">
				<h1>Create Barcode</h1>
				<div id="titlediv">
					<form method="POST" action="'.plugins_url("/barcode/barcode-register.php").'">
						<div class="text-center" style="font-size: 19px; margin-bottom: 2%">
							'.$status_cikti.'
						</div>
						<div id="titlewrap" class="group">
							<input type="text" name="barcode" size="30" id="title" spellcheck="true" autocomplete="off" class="input" placeholder="Barcode">

							<input type="submit" style="padding: 1% 3%; font-size: 18px; font-weight: 500; border-radius: 1rem; border: solid 1px lightblue; background-color: lightblue; margin-top: 1%; cursor: pointer" value="Create Barcode">
						</div>
					</form>
				</div>
			</div>
		</div>';
	}

	add_action('admin_menu', 'barcode_menu');
	function barcode_menu(){
		add_menu_page('Barcode','Barcode', 'manage_options', 'barcode', 'barcode_manage');
	}



	function barcode_query_func() {
		global $wpdb;
   		wp_enqueue_style('style');
		
		// Query Data
   		$table_name = $wpdb->prefix . "barcode";
		$field_name = 'query_time';
		$barcode2 = sanitize_text_field($_GET['barcode']);
		// Query
		$prepared_statement = $wpdb->prepare("SELECT {$field_name} FROM {$table_name} WHERE barcode='%s' ORDER BY id DESC LIMIT %d", $barcode2, 1);
		$values = $wpdb->get_col($prepared_statement);
		
		// Check is barcode found
		if($values && count($values)){
			foreach($values as $barcode_out) {
				$query_time = $barcode_out;
				$query_time++;
				if ($query_time==1){
					echo '<p class="text-center"><img class="barcode-icon" src="'.plugins_url("/barcode/assets/img/success.png").'"></p><p style="text-align:center;">'.$barcode2.' barcode code was queried for the '.$query_time. ". time</p>";
				}
				else if ($query_time>0) {
					echo '<p class="text-center"><img class="barcode-icon" src="'.plugins_url("/barcode/assets/img/error.png").'"></p><p style="text-align:center;">'.$barcode2.' barcode code was queried for the '.$query_time. ". time</p>";
				}
				$wpdb->update( $table_name, array( 'query_time' => $query_time),array('barcode'=>$barcode2));
			}
		}
		else if($barcode2) {
			echo '<p class="text-center"><img class="barcode-icon" src="'.plugins_url("/barcode/assets/img/danger.png").'"></p><p style="text-align:center;">'.$barcode2.' barcode code couldn\'t find.</p>';
		}
			
	$return_data = '<form method="GET" action="" style="text-align:center">
			<label style="margin-bottom: 0!important">
				<span class="wpcf7-form-control-wrap">
					<input type="text" name="barcode" value="'.$barcode2.'" class="custom-barcode-input-class" aria-invalid="false" placeholder="Barcode *">
				</span>
			</label>
			<input type="submit" value="Barcode Lookup" class="custom-barcode-submit-class">
		</form>';
		
    return $return_data;
	}
	add_shortcode('barcode_reader', 'barcode_query_func'); 
?>