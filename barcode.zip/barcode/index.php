<?php
/*
Plugin Name: Barcode Reader
Description: Barkod okuyucu
Version: 1.0
Author: Medialesta
Author URI: https://medialesta.com.tr/
License: GNU
*/	
defined( 'WPINC' ) || exit;
	global $wpdb;


   	
   function creating_plugin_table(){
		global $wpdb;
   		$table_name = $wpdb->prefix . "barcode";
	   	if(!$wpdb->get_var("show tables like '$table_name'")){
		    $sql = "CREATE TABLE ".$table_name." (
		      	id bigint(20) NOT NULL AUTO_INCREMENT,
		      	barcode text(500) NOT NULL,
		      	query_time int(100) NOT NULL,
		      	UNIQUE KEY id (id)
		    )";
	      	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	      	dbDelta($sql);
	   	}
	}

	register_activation_hook( __FILE__, 'creating_plugin_table' );


	function add_my_custom_page() {
    // Create post object
    $my_post = array(
      'post_title'    => wp_strip_all_tags( 'Originality' ),
      'post_content'  => '[barcode_reader]',
      'post_status'   => 'publish',
      'post_author'   => 1,
      'post_type'     => 'page',
    );

    // Insert the post into the database
    wp_insert_post( $my_post );
	}

	register_activation_hook(__FILE__, 'add_my_custom_page');


	function barcode_manage(){
		global $wpdb;
   		$table_name = $wpdb->prefix . "barcode";
		$status = $_GET['status'];
		if($status){
			if(is_numeric($status)){
				if($status==1){
					$status_cikti = '<span style="color: #4be159">Barkod Eklendi</span>';
				}
				else if($status==0){
					$status_cikti = '<span style="color: red">Barkod eklenirken hata oluştu!!</span>';
				}
				else if($status==2){
					$status_cikti = '<span style="color: red">Barkod zaten kayıtlı!</span>';
				}
				else {
					$status_cikti = '<span style="color: red">HATA!</span>';
				}
			}
			else {
				$status_cikti = '<span style="color: red">HATA!</span>';
			}
		}
		echo '
		<div class="row" style="margin: 0">
			<div class="col-md-6 col-12">
				<h1>Barkod Listesi</h1>
				<div class="col-12">
					<div class="inside">
						<table  class="form-table">
							<tr>
								<td scope="row" valign="top">
									<b>Kayıtlı Barkodlar</b>
								</td>

							</tr>';
								$barcode = $wpdb->get_col("SELECT barcode FROM $table_name ORDER BY id DESC");
								if($wpdb->num_rows){
									foreach($barcode as $barcode_out) {
										echo '<tr><td>'.$barcode_out . "</td></tr>";
									}	
								}
								else {
									echo '<tr><td><span style="color: red">Kayıtlı barkod yok</span></td></tr>';
								}
							echo '
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-5 col-12">
				<h1>Barkod Ekle</h1>
				<div id="titlediv">
					<form method="POST" action="'.plugins_url("/barcode/barcode-register.php").'">
						<div class="text-center" style="font-size: 19px; margin-bottom: 2%">
							'.$status_cikti.'
						</div>
						<div id="titlewrap" class="group">
							<input type="text" name="barcode" size="30" id="title" spellcheck="true" autocomplete="off" class="input" placeholder="Barkod">

							<input type="submit" style="padding: 0.2% 1.5%; font-size: 18px; font-weight: 500; border-radius: 1rem; border: solid 1px lightblue; background-color: lightblue; margin-top: 1%;" value="Barkod Ekle">
						</div>
					</form>
				</div>
			</div>
		</div>

		';
		echo '
	<style>
		.text-center {
			text-align: center;
		}
		.text-right {
			text-align: right;
		}
		.row {
			display: -webkit-box;
		    display: -ms-flexbox;
		    display: flex;
		    -ms-flex-wrap: wrap;
		    flex-wrap: wrap;
		    margin-right: -15px;
		    margin-left: -15px;
		}
		.col-md-6 {
			flex: 0 0 50% !important;
    		max-width: 50% !important;
		}
		.col-md-5 {
			-ms-flex: 0 0 41.666667% !important;
		    flex: 0 0 41.666667% !important;
		    max-width: 41.666667% !important;
		}
		.col-12 {
			flex: 0 0 100%;
    		max-width: 100%;
    		float: left;
		}
		.text-center {
			text-align: center;
		}table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
	}

	td, th {
	  border: 1px solid #dddddd;
	  text-align: left;
	  padding: 8px;
	}

	tr:nth-child(even) {
	  background-color: #dddddd;
	}
	</style>
	';
	}

	add_action('admin_menu', 'barcode_menu');
	function barcode_menu(){
		add_menu_page('Barcode','Barcode', 'manage_options', 'barcode', 'barcode_manage');
	}



	function barcode_query_func() {
		global $wpdb;

		$barcode2 = $_GET['barcode'];

   		$table_name = $wpdb->prefix . "barcode";
		$barcode = $wpdb->get_col("SELECT query_time FROM $table_name WHERE barcode='$barcode2' ORDER BY id DESC");
		foreach($barcode as $barcode_out) {
			$query_time = $barcode_out;
			$query_time++;
			echo '<p>'.$barcode2.' barcode code was queried for the '.$query_time. ". time</p>";
		}
		$wpdb->update( $table_name, array( 'query_time' => $query_time),array('barcode'=>$barcode2));

	
    return '<style>.custom-barcode-input-class {
	    height: 55px;
    border-radius: 30px 30px 30px 30px;
    padding: 18px 0px 18px 30px;
    margin: 0px 0px 21px 0px;
    background-color: var( --e-global-color-fb030aa );
    border-style: solid;
    border-width: 0px 0px 0px 0px;
	 }
	 .custom-barcode-submit-class {
	 font-size: 16px;
    font-weight: 500;
    text-transform: capitalize;
    line-height: 1.4em;
    width: 213px;
    height: 61px;
    border-radius: 30px 30px 30px 30px!important;
    padding: 0px 0px 0px 0px;
    margin: 4px 0px 0px 0px;
    background-color: var( --e-global-color-primary )!important;
    transition: all ease-out 0.3s;
}
	 
	 }</style>
			<form method="GET" action="" style="text-align:center">
				<label><span class="wpcf7-form-control-wrap"><input type="text" name="barcode" value="'.$barcode2.'" class="custom-barcode-input-class wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Barcode *"></span></label>
				<input type="submit" value="Barcode Lookup" class="wpcf7-form-control has-spinner wpcf7-submit custom-barcode-submit-class">
			</form>';
	}
	add_shortcode('barcode_reader', 'barcode_query_func'); 
?>